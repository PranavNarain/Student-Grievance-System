	<div class="footer">
		<div class="container">
			 <?php echo date("d.M.Y/D"); ?> <br>

			<b> SGS | MECS</b> 
		</div>
	</div>