 <footer class="site-footer">
          <div class="text-center">
          <?php echo date("d.M.Y/D"); ?> <br>
              SGS | MECS 
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>